
package com.cg.banking.daoservices;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import java.util.Random;
public class BankingDAOServicesImpl implements BankingDAOServices {
	public int i;
	private static Customer[] customerList=new Customer[3];
	private static int CUSTOMER_ID_COUNTER=100; 
	private static int CUSTOMER_IDX_COUNTER=0,account_No_Generator;
	private static int TRANSACTION_ID_COUNTER=110;
	@Override
	public int insertCustomer(Customer customer) {
		customer.setCustomerId(CUSTOMER_ID_COUNTER++);
		customerList[CUSTOMER_IDX_COUNTER++]=customer;
		return customer.getCustomerId();
	}
	/*@Override
	public long insertAccount(int customerId, Account account){
		account.setAccountNo(account_No_Generator++);
		getCustomer(customerId).getAccount()[customerList[i].getAccount_id_counter()]=account;
		customerList[i].setAccount_id_counter(customerList[i].getAccount_id_counter()+1);
		return 0;
	}*/
	/*@Override
	public long insertAccount(int customerId, Account account) {
		account.setAccountNo(account_No_Generator);
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null && customerId == customerList[i].getCustomerId()){
				//	for(int j=0;j<customerList[i].getAccount().length;j++){
				customerList[i].getAccount()[customerList[i].getAccount_id_counter()]=account;
				customerList[i].setAccount_id_counter(customerList[i].getAccount_id_counter()+1);
				return customerList[i].getAccount()[customerList[i].getAccount_id_counter()-1].getAccountNo();
			}
		return 0;

	}*/
	@Override
	public long insertAccount(int customerId, Account account){
		account.setAccountNo(account_No_Generator);
		getCustomer(customerId).getAccount()[getCustomer(customerId).getAccount_idx_counter()]=account;
		getCustomer(customerId).setAccount_idx_counter(getCustomer(customerId).getAccount_idx_counter()+1);
		return getCustomer(customerId).getAccount()[getCustomer(customerId).getAccount_idx_counter()-1].getAccountNo();
	}
	
	@Override
	public boolean updateAccount(int customerId, Account account) {
		for(int j=0;j<getCustomer(customerId).getAccount().length;j++)
			if(getCustomer(customerId).getAccount()[j].getAccountNo()==account.getAccountNo()) {
				getCustomer(customerId).getAccount()[j]=account;
				return true;
			}
		return false;
	}
	@Override
	public int generatePin(int customerId, Account account) {
		Random rand = new Random();
		int num = rand.nextInt(9000) + 1000;
		return 0;
	}
	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		transaction.setTransactionId(TRANSACTION_ID_COUNTER++);

		//return transaction.getTransactionId();
		return false;
	}
	@Override
	public boolean deleteCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null && customerId==customerList[i].getCustomerId()){
				customerList[i]=null;
				return true;
			}
		return false;
		
	}
	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		for(i=0;i<getCustomer(customerId).getAccount().length;i++)	
		if(getCustomer(customerId).getAccount()[i].getAccountNo()==accountNo){
		getCustomer(customerId).getAccount()[i]=null;
		return true;
	}
		return false;
	}
	@Override
	public Customer getCustomer(int customerId) {
		for(i=0;i<customerList.length;i++)
			if(customerList[i]!=null && customerId==customerList[i].getCustomerId()){
				return customerList[i];
			}
		return null;
	}
	@Override
	public Account getAccount(int customerId, long accountNo) {
		for(i=0;i<getCustomer(customerId).getAccount().length;i++)
			if(getCustomer(customerId).getAccount()[i].getAccountNo()==accountNo){
				return getCustomer(customerId).getAccount()[i];
			}
		return null;
	}
	@Override
	public Customer[] getCustomers() {

		return null;
	}
	@Override
	public Account[] getAccounts(int customerId) {

		return null;
	}
	@Override
	public Transaction[] getTransactions(int customerId, long accountNo) {

		return null;
	}



}
