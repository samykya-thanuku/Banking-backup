package com.cg.banking.main;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;



public class MainClass {
	public static void main(String[] args) {
		//Customer[] customers = new Customer[2];
		//customers[0]=new Customer(123, 123654, 112233, "SAM", "DSDS", "derdf", "4-jan-95", new Address(1234, "hyd", "rtrt", "india"), new Account(12345698, 125555, "Savings", new Transactions(1256478, "erd", 256644, "segg", "hyd", "Card", "success")));	
	}


	

}
